Background Posed Humans GLB Pack - 28 Free CC0 3D Models

This is a GLB-ready convenience package based on Background Posed Humans Pack by Quaternius.

Included:
- 28 static GLB models in models_glb/
- MODEL_LIST.csv
- Original source preview and license text in source_reference/
- Source and license verification notes

Intended use:
Background crowds, manga and illustration scene reference, city scenes,
school scenes, event layouts, scale reference, and Clip Studio Paint
background workflows.

Source:
- Background Posed Humans Pack / Quaternius
- https://quaternius.com/packs/backgroundposedhumans.html
- Creator: Quaternius
- License: Creative Commons Zero (CC0)
- CC0: https://creativecommons.org/publicdomain/zero/1.0/
- License checked: 2026-05-09 JST

Note:
This is not an official Quaternius product. Eclair Assets redistributes this
package as a convenience GLB version with source and license notes kept together.
